package com.projity.pm.task;

public interface HasProject {
	public Project getProject();
}
