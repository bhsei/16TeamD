#!/bin/bash
gzip --best -c $1 > $2