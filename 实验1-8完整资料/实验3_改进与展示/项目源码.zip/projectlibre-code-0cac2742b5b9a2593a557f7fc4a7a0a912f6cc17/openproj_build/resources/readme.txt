Running ProjectLibre @version_name@

Requirements:
	ProjectLibre uses Java version 6 or later.
	To see what version you have, check out this page:
	http://www.java.com/en/download/help/testvm.xml

	You can download java here:  http://www.java.com/en/download/index.jsp

Installation:
	Unzip the files to the folder of your choice.

	Windows: Click on projectlibre.jar (or projectlibre.bat)

	Mac: Click on projectlibre.jar

	Linux: Open a terminal, go to the projectlibre folder and run ./projectlibre.sh (assuming you downloaded the tar.gz archive)
			If you get a permission denied message, do "chmod +x projectlibre.sh"  This will let you run the shell script.
			You can also run with the command "sh projectlibre.sh"

			projectlibre.sh  will report an error if it doesn't find a valid Java installation on your system.
			On some distributions Java Runtime Environment (JRE) isn't installed by default, but it's often provided as an optional package.
